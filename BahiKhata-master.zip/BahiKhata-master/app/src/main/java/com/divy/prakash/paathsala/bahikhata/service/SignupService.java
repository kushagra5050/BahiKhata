package com.divy.prakash.paathsala.bahikhata.service;

/* This Interface Is Used To Implement Method For Calculation */
public interface SignupService {
}
