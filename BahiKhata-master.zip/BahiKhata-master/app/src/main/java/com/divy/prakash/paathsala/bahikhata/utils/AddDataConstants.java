package com.divy.prakash.paathsala.bahikhata.utils;

/* This Class Is Used To Create A Constant Fields Of Add Data */
public class AddDataConstants {
    public static String PRODUCTNAME = "productname";
    public static String QUANTITY = "quantity";
    public static String MEASURINGUNIT = "measuringunit";
    public static String PRICEPERUNIT = "priceperunit";
    public static String TOTALPRICE = "totalprice";
    public static String POSITION = "position";
}
