package com.divy.prakash.paathsala.bahikhata.utils;

/* This Class Is Used To Create Constant For DATABASE */
public class DataBaseConstants {
    public static final String DATABASE_NAME = "BAHIKHATALOGIN.db";
    public static final int DATABASE_VERSION = 1;
}
