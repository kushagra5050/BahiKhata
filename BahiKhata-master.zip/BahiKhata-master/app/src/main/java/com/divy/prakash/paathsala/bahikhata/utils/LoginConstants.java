package com.divy.prakash.paathsala.bahikhata.utils;

/* This Class Is Used To Create A Constant Fields Of User */
public class LoginConstants {
    public static String COL_ID = "id";
    public static String COL_SHOPNAME = "shopname";
    public static String COL_EMAIL = "email";
    public static String COL_CONTACT = "contact";
    public static String COL_USERID = "userid";
    public static String COL_PASSWORD = "password";
}
