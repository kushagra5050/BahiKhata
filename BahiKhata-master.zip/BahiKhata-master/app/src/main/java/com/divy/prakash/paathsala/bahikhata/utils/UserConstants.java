package com.divy.prakash.paathsala.bahikhata.utils;

/* This Class Is Used To Create A Constant Fields Of User */
public class UserConstants {
    public String id;
    public String shopName;
    public String email;
    public String contact;
    public String userID;
    public String password;

    public UserConstants(String id, String shopName, String email, String contact, String userID, String password) {
        this.id = id;
        this.shopName = shopName;
        this.email = email;
        this.contact = contact;
        this.userID = userID;
        this.password = password;

    }

}